const fs = require('fs');
const path = require('path');

/**
 * CoverScore Platform Blueprint™ v2 (Master Edition)
 * Question Pack Factory™
 * 
 * This engine generates the entire question bank from a standardized inheritance model.
 * Master Template (QP-100) dictates the conversation, lead capture, and closing engines.
 * All other Question Packs (QP-110 to QP-270) inherit these engines and only define overrides.
 */

class QuestionPackFactory {
  constructor() {
    this.questionBank = [];
  }

  // 1. Conversation Engine (Welcome, Tell Me More, Consent)
  buildConversationEngine(config) {
    const p = config.prefix;
    const isBiz = config.type === 'business';

    return [
      {
        id: `${p}_001`,
        industry: config.ind,
        pillar: 'General',
        question: `👋 Hello and welcome to CoverScore™.\n\nYou're about to discover how ${isBiz ? 'prepared your business is' : 'financially and personally prepared you are'} for unexpected life events.\n\nThis assessment takes about 5 minutes and you'll receive your personalized Risk Intelligence Report™ immediately after completion.\n\nThere are no right or wrong answers—just answer honestly.\n\nShall we begin?`,
        question_type: 'single_choice',
        answers: ["✅ Yes, let's begin", '❓ Tell me more'],
        branching: { "✅ Yes, let's begin": `${p}_003`, '❓ Tell me more': `${p}_002`, 'DEFAULT': `${p}_002` }
      },
      {
        id: `${p}_002`,
        industry: config.ind,
        pillar: 'General',
        question: `CoverScore helps people identify hidden risks before those risks become expensive problems.\n\nAt the end of this assessment, you'll receive:\n• Your overall CoverScore™\n• Your strongest areas\n• Your biggest risk gaps\n• Practical recommendations\n• Learning resources\n• Protection recommendations (where appropriate)\n\nReady to begin?`,
        question_type: 'single_choice',
        answers: ['✅ Start Assessment'],
        branching: { '✅ Start Assessment': `${p}_003`, 'DEFAULT': `${p}_003` }
      },
      {
        id: `${p}_003`,
        industry: config.ind,
        pillar: 'General',
        question: `Before we begin, we'd like your permission to securely process your responses so we can prepare your personalized report.\n\nYour information will remain private and will never be shared without your consent.\n\nDo you agree?`,
        question_type: 'single_choice',
        answers: ['✅ I Agree', '❌ Not Now'],
        branching: { '✅ I Agree': `${p}_004`, '❌ Not Now': 'COMPLETE', 'DEFAULT': 'COMPLETE' }
      }
    ];
  }

  // 2. Lead Capture Engine
  buildLeadCaptureEngine(config) {
    const p = config.prefix;
    let qs = [];
    if (config.type === 'business') {
      qs = [
        {
          id: `${p}_004`, industry: config.ind, pillar: 'General',
          question: `Great.\n\nTo personalize your report, what is the name of your ${config.audience}?`,
          question_type: 'open_text', data_mapping: 'business_name',
          branching: { 'DEFAULT': `${p}_005` }
        },
        {
          id: `${p}_005`, industry: config.ind, pillar: 'General',
          question: `Thanks!\n\nAnd what is your name?`,
          question_type: 'open_text', data_mapping: 'name',
          branching: { 'DEFAULT': `${p}_006` }
        },
        {
          id: `${p}_006`, industry: config.ind, pillar: 'General',
          question: `Nice to meet you.\n\nWhat is your role?`,
          question_type: 'open_text', data_mapping: 'role',
          branching: { 'DEFAULT': `${p}_007` }
        },
        {
          id: `${p}_007`, industry: config.ind, pillar: 'General',
          question: `Finally, what is your email address?\n\n(We'll send your completed Risk Report here)`,
          question_type: 'open_text', data_mapping: 'email',
          branching: { 'DEFAULT': `${p}_008` }
        }
      ];
    } else {
      qs = [
        {
          id: `${p}_004`, industry: config.ind, pillar: 'General',
          question: `Great.\n\nTo personalize your report, what is your full name?`,
          question_type: 'open_text', data_mapping: 'name',
          branching: { 'DEFAULT': `${p}_005` }
        },
        {
          id: `${p}_005`, industry: config.ind, pillar: 'General',
          question: `Nice to meet you.\n\nFinally, what is your email address?\n\n(We'll send your completed Risk Report here)`,
          question_type: 'open_text', data_mapping: 'email',
          branching: { 'DEFAULT': `${p}_006` }
        }
      ];
    }
    return qs;
  }

  // 3. Closing & Advisor Integration Engine
  buildClosingEngine(config, startId) {
    const p = config.prefix;
    const currentInsuranceAnswers = config.type === 'business' 
      ? ['Fire & Property', 'Group Life / Health', 'Public Liability', 'Cyber Security', 'Motor / Fleet', 'None of the above']
      : ['Life Insurance', 'Health Insurance (HMO)', 'Vehicle Insurance', 'Property / Home', 'None of the above'];

    return [
      {
        id: `${p}_${String(startId).padStart(3, '0')}`,
        industry: config.ind,
        pillar: 'General',
        question: `Which of these insurances do you currently have? (Select all that apply, e.g., A, C)`,
        question_type: 'multi_choice',
        answers: currentInsuranceAnswers,
        data_mapping: 'existing_insurance',
        branching: { 'DEFAULT': `${p}_${String(startId + 1).padStart(3, '0')}` }
      },
      {
        id: `${p}_${String(startId + 1).padStart(3, '0')}`,
        industry: config.ind,
        pillar: 'General',
        question: `Thank you for completing the core assessment!\n\nBased on your responses, we've identified potential protection gaps.\n\nWould you like a complimentary 15-minute consultation with a Risk Advisor?`,
        question_type: 'single_choice',
        answers: ['Yes, please', 'No, just send my report'],
        data_mapping: 'consultation_preference',
        branching: { 'Yes, please': `${p}_${String(startId + 2).padStart(3, '0')}`, 'No, just send my report': 'COMPLETE', 'DEFAULT': 'COMPLETE' }
      },
      {
        id: `${p}_${String(startId + 2).padStart(3, '0')}`,
        industry: config.ind,
        pillar: 'General',
        question: `Great! What time of day works best for a brief call?`,
        question_type: 'single_choice',
        answers: ['Morning', 'Afternoon', 'Evening'],
        data_mapping: 'consultation_time',
        branching: { 'DEFAULT': 'COMPLETE' }
      }
    ];
  }

  // The Factory Pipeline
  buildQuestionPack(config) {
    console.log(`Building Question Pack: ${config.id} (${config.name}) - Inherits: ${config.parent}`);
    let qs = [];
    
    // 1. Load Conversation Engine
    qs.push(...this.buildConversationEngine(config));
    
    // 2. Load Lead Capture Engine
    const leadCapture = this.buildLeadCaptureEngine(config);
    qs.push(...leadCapture);

    let nextId = config.type === 'business' ? 8 : 6;

    // 3. Apply Overrides (Risk Pillars & Question Library)
    if (config.overrides && config.overrides.specific_questions) {
      config.overrides.specific_questions.forEach(q => {
        const id = `${config.prefix}_${String(nextId).padStart(3, '0')}`;
        const nextIdStr = `${config.prefix}_${String(nextId + 1).padStart(3, '0')}`;
        
        q.id = id;
        q.industry = config.ind;
        q.pillar = q.pillar || 'Exposure'; // Default pillar, can be overridden per question
        if (!q.branching) {
          q.branching = { 'DEFAULT': nextIdStr };
        }
        
        qs.push(q);
        nextId++;
      });
    }

    // 4. Load Closing Engine
    qs.push(...this.buildClosingEngine(config, nextId));
    
    this.questionBank.push(...qs);
  }

  export(filePath) {
    fs.writeFileSync(filePath, JSON.stringify(this.questionBank, null, 2), 'utf8');
    console.log(`✅ Successfully generated ${this.questionBank.length} questions across all Question Packs.`);
  }
}

// ---------------------------------------------------------
// QUESTION PACK LIBRARY CONFIGURATION
// ---------------------------------------------------------

const questionPacks = [
  
  // ==========================================
  // PERSONAL LIBRARY
  // ==========================================
  
  {
    id: 'QP-100', parent: 'Master', prefix: 'YPR', name: 'Young Professional', ind: 'young_professional', type: 'personal', audience: 'young professional',
    overrides: {
      specific_questions: [
        { pillar: 'Career & Income Security', question: `How long have you been in your current career?`, question_type: 'single_choice', answers: ['Under 2 years', '2-5 years', 'Over 5 years'] },
        { pillar: 'Financial Resilience', question: `If you suffered a critical illness (e.g. cancer, stroke) today, could you afford the medical bills without going into debt?`, question_type: 'single_choice', answers: ['Yes easily', 'With difficulty', 'No'], risk_logic: { 'With difficulty': { vulnerability_points: 20 }, 'No': { vulnerability_points: 40 } } },
        { pillar: 'Financial Resilience', question: `Do you have an emergency fund covering at least 6 months of expenses?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Protection & Insurance', question: `Do you currently have personal Health or Accident Insurance?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 20 } } },
        { pillar: 'Future Planning', question: `Are you currently saving towards a major life goal (e.g. buying a house, marriage)?`, question_type: 'yes_no', answers: ['Yes', 'No'] }
      ]
    }
  },
  {
    id: 'QP-110', parent: 'QP-100', prefix: 'ENT', name: 'Entrepreneur', ind: 'entrepreneur', type: 'personal', audience: 'entrepreneur',
    overrides: {
      specific_questions: [
        { pillar: 'Business Continuity', question: `Does your business's revenue completely rely on your personal involvement?`, question_type: 'single_choice', answers: ['Yes completely', 'Partially', 'No it runs itself'], risk_logic: { 'Yes completely': { vulnerability_points: 30 }, 'Partially': { vulnerability_points: 15 } } },
        { pillar: 'Legal & Liability', question: `Have you provided personal guarantees for any business loans or debts?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'Yes': { exposure_points: 25 } } },
        { pillar: 'Business Continuity', question: `If you were hospitalized for 3 months, would your business survive?`, question_type: 'single_choice', answers: ['Yes', 'No', 'Not sure'], risk_logic: { 'No': { vulnerability_points: 40 }, 'Not sure': { vulnerability_points: 20 } } },
        { pillar: 'Employees', question: `Do you have Key Person Insurance to protect the business if a vital team member is lost?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Protection & Insurance', question: `Are your personal assets properly separated and protected from business liabilities?`, question_type: 'yes_no', answers: ['Yes', 'No', 'Not sure'], risk_logic: { 'No': { exposure_points: 30 }, 'Not sure': { exposure_points: 15 } } }
      ]
    }
  },
  {
    id: 'QP-120', parent: 'QP-100', prefix: 'FAM', name: 'Family Protection', ind: 'family', type: 'personal', audience: 'family member',
    overrides: {
      specific_questions: [
        { pillar: 'Personal Profile', question: `How many dependents (children or elderly relatives) rely on your income?`, question_type: 'single_choice', answers: ['None', '1-2', '3 or more'], risk_logic: { 'None': { exposure_points: 5 }, '1-2': { exposure_points: 20 }, '3 or more': { exposure_points: 35 } } },
        { pillar: 'Career & Income Security', question: `If you were suddenly unable to work due to illness, how long would your savings last?`, question_type: 'single_choice', answers: ['Less than 3 months', '3-6 months', 'Over 6 months'], risk_logic: { 'Less than 3 months': { vulnerability_points: 35 }, '3-6 months': { vulnerability_points: 15 } } },
        { pillar: 'Protection & Insurance', question: `Do you currently have a Life Insurance policy?`, question_type: 'yes_no', answers: ['Yes', 'No', 'Not sure'], risk_logic: { 'No': { vulnerability_points: 30 }, 'Not sure': { vulnerability_points: 20 } } },
        { pillar: 'Future Planning', question: `Are your children's future education costs secured if something happens to the primary breadwinner?`, question_type: 'yes_no', answers: ['Yes', 'No', 'Not applicable'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Health & Wellbeing', question: `Does your family have comprehensive Health Insurance?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } }
      ]
    }
  },
  {
    id: 'QP-130', parent: 'QP-100', prefix: 'INC', name: 'Income Protection', ind: 'income', type: 'personal', audience: 'income earner',
    overrides: {
      specific_questions: [
        { pillar: 'Career & Income Security', question: `What is your primary source of income?`, question_type: 'single_choice', answers: ['Salary from employment', 'Freelance/Contract', 'Business owner'] },
        { pillar: 'Financial Resilience', question: `If you lost your primary income tomorrow, how long would your emergency funds last?`, question_type: 'single_choice', answers: ['Less than 1 month', '1-3 months', 'Over 3 months'], risk_logic: { 'Less than 1 month': { vulnerability_points: 40 }, '1-3 months': { vulnerability_points: 20 } } },
        { pillar: 'Career & Income Security', question: `Do you have secondary sources of income (e.g. investments, real estate)?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 10 } } },
        { pillar: 'Protection & Insurance', question: `Do you currently have a policy that pays you a monthly income if you are disabled by an accident?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Financial Resilience', question: `Do you have significant debts (mortgage, personal loans) that require monthly repayments?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'Yes': { exposure_points: 25 } } }
      ]
    }
  },
  {
    id: 'QP-140', parent: 'QP-100', prefix: 'HLT', name: 'Health Protection', ind: 'health', type: 'personal', audience: 'individual',
    overrides: {
      specific_questions: [
        { pillar: 'Protection & Insurance', question: `Do you currently have a Health Maintenance Organization (HMO) or health insurance plan?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 35 } } },
        { pillar: 'Protection & Insurance', question: `If yes, are you satisfied with the limits and coverage of your current health plan?`, question_type: 'single_choice', answers: ['Yes', 'No', "I don't have one"] },
        { pillar: 'Financial Resilience', question: `Have you or a close family member ever had to pay out-of-pocket for a major medical emergency?`, question_type: 'yes_no', answers: ['Yes', 'No'] },
        { pillar: 'Health & Wellbeing', question: `Is there a history of critical illnesses (e.g., heart disease, cancer) in your family?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'Yes': { exposure_points: 30 } } },
        { pillar: 'Protection & Insurance', question: `Do you have a Critical Illness insurance policy that pays a lump sum upon diagnosis?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } }
      ]
    }
  },
  {
    id: 'QP-150', parent: 'QP-100', prefix: 'RET', name: 'Retirement Planning', ind: 'retirement', type: 'personal', audience: 'future retiree',
    overrides: {
      specific_questions: [
        { pillar: 'Future Planning', question: `How soon do you plan to retire?`, question_type: 'single_choice', answers: ['Within 5 years', '5-15 years', 'Over 15 years'], risk_logic: { 'Within 5 years': { exposure_points: 30 }, '5-15 years': { exposure_points: 15 } } },
        { pillar: 'Financial Resilience', question: `Do you have a dedicated Pension or Retirement Savings Account (RSA)?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 40 } } },
        { pillar: 'Health & Wellbeing', question: `Are you concerned that escalating medical costs might deplete your retirement savings?`, question_type: 'single_choice', answers: ['Very concerned', 'Somewhat concerned', 'Not concerned'] },
        { pillar: 'Protection & Insurance', question: `Do you have a plan in place for long-term care or critical illness during retirement?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Future Planning', question: `If you pass away, will your spouse or dependents have enough income to maintain their lifestyle?`, question_type: 'single_choice', answers: ['Yes', 'No', 'Not applicable'], risk_logic: { 'No': { vulnerability_points: 30 } } }
      ]
    }
  },
  // Future Placeholder Example
  {
    id: 'QP-160', parent: 'QP-100', prefix: 'HOM', name: 'Home Protection', ind: 'home', type: 'personal', audience: 'homeowner',
    overrides: {
      specific_questions: [
        { pillar: 'Property & Assets', question: `Do you currently own or rent your primary residence?`, question_type: 'single_choice', answers: ['Own', 'Rent', 'Neither'] },
        { pillar: 'Protection & Insurance', question: `Do you have Homeowner's or Renter's Insurance covering your personal property?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 30 } } }
      ]
    }
  },
  {
    id: 'QP-170', parent: 'QP-100', prefix: 'MOT', name: 'Motor Protection', ind: 'motor', type: 'personal', audience: 'vehicle owner',
    overrides: {
      specific_questions: [
        { pillar: 'Property & Assets', question: `How many vehicles do you currently own or lease?`, question_type: 'single_choice', answers: ['1', '2', '3 or more'] },
        { pillar: 'Protection & Insurance', question: `Is your primary vehicle covered by Comprehensive Motor Insurance?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 40 } } }
      ]
    }
  },
  
  // ==========================================
  // BUSINESS LIBRARY
  // ==========================================
  
  {
    id: 'QP-200', parent: 'QP-100', prefix: 'SME', name: 'SME', ind: 'sme', type: 'business', audience: 'business',
    overrides: {
      specific_questions: [
        { pillar: 'Employees', question: `How many employees/staff do you have?`, question_type: 'single_choice', answers: ['1-10', '11-50', '51+'], risk_logic: { '1-10': { exposure_points: 5 }, '11-50': { exposure_points: 15 }, '51+': { exposure_points: 25 } } },
        { pillar: 'Cash Flow', question: `What is your estimated annual revenue?`, question_type: 'single_choice', answers: ['Under ₦50M', '₦50M - ₦200M', 'Over ₦200M'], risk_logic: { 'Under ₦50M': { exposure_points: 10 }, '₦50M - ₦200M': { exposure_points: 20 }, 'Over ₦200M': { exposure_points: 30 } } },
        { pillar: 'Facilities', question: `Do you operate from a physical shop or office?`, question_type: 'yes_no', answers: ['Yes', 'No'] },
        { pillar: 'Protection & Insurance', question: `Do you currently have a comprehensive Fire & Burglary Insurance policy?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Business Continuity', question: `If a major disaster forced you to close for 3 months, could you survive without revenue?`, question_type: 'single_choice', answers: ['Yes easily', 'With difficulty', 'No, we would close'], risk_logic: { 'With difficulty': { impact_points: 20 }, 'No, we would close': { impact_points: 40 } } }
      ]
    }
  },
  {
    id: 'QP-210', parent: 'QP-100', prefix: 'MFG', name: 'Manufacturing', ind: 'manufacturing', type: 'business', audience: 'manufacturing plant',
    overrides: {
      specific_questions: [
        { pillar: 'Employees', question: `How many factory workers do you employ?`, question_type: 'single_choice', answers: ['1-50', '51-200', '200+'], risk_logic: { '1-50': { exposure_points: 10 }, '51-200': { exposure_points: 20 }, '200+': { exposure_points: 30 } } },
        { pillar: 'Operations', question: `If a critical machine breaks down, how quickly would it halt operations?`, question_type: 'single_choice', answers: ['Immediately', 'Within a few days', 'We have backups'], risk_logic: { 'Immediately': { vulnerability_points: 30 }, 'Within a few days': { vulnerability_points: 15 } } },
        { pillar: 'Logistics', question: `Do you import raw materials or export finished goods?`, question_type: 'yes_no', answers: ['Yes', 'No'], recommendation_trigger: { condition: 'Yes', recommendation: 'Marine/Goods In Transit Insurance required' } },
        { pillar: 'Protection & Insurance', question: `Do you have comprehensive Fire & Special Perils insurance for your warehouse/factory?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 30 } } },
        { pillar: 'Business Continuity', question: `If a major fire forced you to close for 3 months, could you survive without revenue?`, question_type: 'single_choice', answers: ['Yes easily', 'With difficulty', 'No, we would close'], risk_logic: { 'With difficulty': { impact_points: 20 }, 'No, we would close': { impact_points: 40 } } }
      ]
    }
  },
  {
    id: 'QP-220', parent: 'QP-100', prefix: 'HOS', name: 'Hospital', ind: 'hospital', type: 'business', audience: 'hospital',
    overrides: {
      specific_questions: [
        { pillar: 'Operations', question: `Approximately how many patient beds does your facility have?`, question_type: 'single_choice', answers: ['Under 20', '20-100', 'Over 100'], risk_logic: { 'Under 20': { exposure_points: 10 }, '20-100': { exposure_points: 20 }, 'Over 100': { exposure_points: 30 } } },
        { pillar: 'Cyber Security', question: `Are patient records stored electronically?`, question_type: 'yes_no', answers: ['Yes', 'No'], recommendation_trigger: { condition: 'Yes', recommendation: 'Cyber Liability Insurance required' } },
        { pillar: 'Legal & Liability', question: `Do you have Medical Malpractice/Professional Indemnity insurance for your doctors and staff?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 35 } } },
        { pillar: 'Facilities', question: `Do you have high-value medical equipment (e.g., MRI, X-Ray) that would be costly to replace?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'Yes': { exposure_points: 15 } } },
        { pillar: 'Protection & Insurance', question: `If a power surge destroyed critical life-support equipment, do you have Machinery Breakdown insurance?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } }
      ]
    }
  },
  {
    id: 'QP-230', parent: 'QP-100', prefix: 'SCH', name: 'School', ind: 'school', type: 'business', audience: 'school',
    overrides: {
      specific_questions: [
        { pillar: 'Operations', question: `How many students are enrolled in your school?`, question_type: 'single_choice', answers: ['Under 100', '100-500', 'Over 500'], risk_logic: { 'Under 100': { exposure_points: 10 }, '100-500': { exposure_points: 20 }, 'Over 500': { exposure_points: 30 } } },
        { pillar: 'Cash Flow', question: `What is the estimated average annual tuition fee per student?`, question_type: 'single_choice', answers: ['Under ₦100,000', '₦100,000 - ₦500,000', 'Over ₦500,000'], data_mapping: 'tuition_fees' },
        { pillar: 'Logistics', question: `Do you operate school buses to transport students?`, question_type: 'yes_no', answers: ['Yes', 'No'], recommendation_trigger: { condition: 'Yes', recommendation: 'Comprehensive Motor Fleet Insurance required' } },
        { pillar: 'Legal & Liability', question: `If a student was injured on the playground and parents sued, do you have Public Liability Insurance?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 30 } } },
        { pillar: 'Protection & Insurance', question: `Do you currently have a comprehensive Fire Insurance policy for your school buildings?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } }
      ]
    }
  },
  {
    id: 'QP-240', parent: 'QP-100', prefix: 'CHR', name: 'Church', ind: 'church', type: 'business', audience: 'church',
    overrides: {
      specific_questions: [
        { pillar: 'Operations', question: `What is your average weekly congregation size?`, question_type: 'single_choice', answers: ['Under 200', '200-1000', 'Over 1000'], risk_logic: { 'Under 200': { exposure_points: 10 }, '200-1000': { exposure_points: 20 }, 'Over 1000': { exposure_points: 40 } } },
        { pillar: 'Facilities', question: `Do you have high-value musical instruments and broadcast equipment on the premises?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'Yes': { exposure_points: 15 } } },
        { pillar: 'Legal & Liability', question: `If a visitor was injured during a service and sued, do you have Public Liability Insurance?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Facilities', question: `Do you own the church building?`, question_type: 'yes_no', answers: ['Yes', 'No'] },
        { pillar: 'Protection & Insurance', question: `Do you currently have Fire Insurance for the building and its contents?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 30 } } }
      ]
    }
  },
  {
    id: 'QP-260', parent: 'QP-100', prefix: 'CON', name: 'Construction', ind: 'construction', type: 'business', audience: 'construction firm',
    overrides: {
      specific_questions: [
        { pillar: 'Operations', question: `How many active construction projects do you typically manage at once?`, question_type: 'single_choice', answers: ['1-2', '3-5', 'More than 5'], risk_logic: { '1-2': { exposure_points: 10 }, '3-5': { exposure_points: 20 }, 'More than 5': { exposure_points: 30 } } },
        { pillar: 'Facilities', question: `Do you use heavy construction machinery (e.g., excavators, cranes)?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'Yes': { exposure_points: 20 } } },
        { pillar: 'Protection & Insurance', question: `Do you currently have Contractors All Risk (CAR) insurance for your sites?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 30 } } },
        { pillar: 'Employees', question: `If a worker is injured on site, do you have Group Personal Accident or Employers Liability insurance?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Business Continuity', question: `If a project is delayed due to an unforeseen accident, do you have cover for the resulting financial loss?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 15 } } }
      ]
    }
  },
  {
    id: 'QP-270', parent: 'QP-100', prefix: 'TRN', name: 'Transport & Logistics', ind: 'transport', type: 'business', audience: 'logistics company',
    overrides: {
      specific_questions: [
        { pillar: 'Operations', question: `How many vehicles are in your fleet?`, question_type: 'single_choice', answers: ['1-5', '6-20', 'Over 20'], risk_logic: { '1-5': { exposure_points: 10 }, '6-20': { exposure_points: 20 }, 'Over 20': { exposure_points: 30 } } },
        { pillar: 'Operations', question: `Do you primarily transport goods (cargo) or passengers?`, question_type: 'single_choice', answers: ['Goods', 'Passengers', 'Both'] },
        { pillar: 'Protection & Insurance', question: `Do you have Goods In Transit (GIT) insurance for the cargo you carry?`, question_type: 'single_choice', answers: ['Yes', 'No', 'Not Applicable'], risk_logic: { 'No': { vulnerability_points: 25 } } },
        { pillar: 'Employees', question: `If a driver is involved in a severe accident, do you have Group Life / Personal Accident cover for them?`, question_type: 'yes_no', answers: ['Yes', 'No'], risk_logic: { 'No': { vulnerability_points: 20 } } },
        { pillar: 'Protection & Insurance', question: `Are your vehicles covered by Comprehensive Motor Insurance?`, question_type: 'single_choice', answers: ['Yes', 'No', 'Some of them'], risk_logic: { 'No': { vulnerability_points: 30 }, 'Some of them': { vulnerability_points: 15 } } }
      ]
    }
  }
];

// Initialize the Factory
const factory = new QuestionPackFactory();

// Build each Question Pack using the Inheritance Model
questionPacks.forEach(pack => {
  factory.buildQuestionPack(pack);
});

// Export the Unified JSON to the Engine
const qbPath = path.join(__dirname, '../src/data/question_bank.json');
factory.export(qbPath);
